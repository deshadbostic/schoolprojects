package my.inventorysystem;

import static java.lang.reflect.Array.set;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import net.proteanit.sql.DbUtils;
import java.util.Date;


public class InventorysystemUI extends javax.swing.JFrame {
Connection con;
   ResultSet rs;
   PreparedStatement stmt;
   java.util.Date date;
   String UserName;
   String Password;
   String username;
   String password;
   int order_id;
   
   
    public InventorysystemUI() {
        initComponents();
        createConnection();
        Update_table();
        setData();
        jLabel11.setVisible(false);
        Total.setVisible(false);
        PromoteUser.setEnabled(false);
        DemoteUser.setEnabled(false);
        AddUser.setEnabled(false);
        RemoveUser.setEnabled(false);
        order_ID.setEnabled(false);
        customer_id.setEnabled(false);
        inventoryTable.getTableHeader().setReorderingAllowed(false);
        customersTable.getTableHeader().setReorderingAllowed(false);
       customersTable2.getTableHeader().setReorderingAllowed(false);
       inventoryTable2.getTableHeader().setReorderingAllowed(false);
        orderTable.getTableHeader().setReorderingAllowed(false);
       ItemSoldTable.getTableHeader().setReorderingAllowed(false);
      UsersTable.getTableHeader().setReorderingAllowed(false);
      AllSales.setEditable(false);
      TotalOrder.setEditable(false);
      OrderTotal.setEditable(false);
            
            
           
        
    }
void createConnection(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/majorproject","root","");
            System.out.println("Success");
           
            
        }  catch(ClassNotFoundException | SQLException ex){
            Logger.getLogger(InventorysystemUI.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error can't connect to sql");
            
        }
        
        
    }
    
    private void setData(){
         try {
           String sql = "SELECT MAX(Orderid) FROM ordertbl";
           stmt = con.prepareStatement(sql);
           rs=stmt.executeQuery();
           while(rs.next()){
               order_id = rs.getInt(1) + 1;
               order_ID.setText(Integer.toString(order_id));
               
           }            
        
        int row = ItemSoldTable.getRowCount();
        double total = 0.0;
        for (int i = 0; i < row; i++){   
             double price = (double)ItemSoldTable.getValueAt(i,2);
             int quantity = (Integer)ItemSoldTable.getValueAt(i,3);
             double result = price * quantity;
             total += result;
                        
         }
        AllSales.setText(Double.toString(total));
           
       } catch (Exception e) {
           System.out.println(e);
       }
    }

    private void Update_table(){
        
       try {
           String sql = "SELECT Itemname, Price, Quantity, Description FROM inventory WHERE Deleted = 'False'";
           stmt = con.prepareStatement(sql);
           rs=stmt.executeQuery();
           inventoryTable.setModel(DbUtils.resultSetToTableModel(rs)); 
             
           sql = "SELECT Customerid, Firstname, Lastname, Address, Telephone, Email FROM customers WHERE Deleted = 'False'";
           stmt = con.prepareStatement(sql);
           rs = stmt.executeQuery();
           customersTable.setModel(DbUtils.resultSetToTableModel(rs));
           
            sql = "SELECT Customerid, Firstname, Lastname, Address, Telephone, Email FROM customers WHERE Deleted = 'False'";
           stmt = con.prepareStatement(sql);
           rs = stmt.executeQuery();
           customersTable2.setModel(DbUtils.resultSetToTableModel(rs));
           
           sql = "SELECT id,Itemname, Price, Quantity, Description FROM inventory WHERE Deleted = 'False'";
           stmt = con.prepareStatement(sql);
           rs = stmt.executeQuery();
           inventoryTable2.setModel(DbUtils.resultSetToTableModel(rs));
           
           sql = "SELECT Orderid, Itemname, Price, Quantitysold  FROM orderdetails";
           stmt = con.prepareStatement(sql);
           rs = stmt.executeQuery();
           ItemSoldTable.setModel(DbUtils.resultSetToTableModel(rs));
           
           sql = "SELECT Userid,Role, Username FROM users";
           stmt = con.prepareStatement(sql);
           rs = stmt.executeQuery();
           UsersTable.setModel(DbUtils.resultSetToTableModel(rs));
           
          
           
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"Unable to refresh one or more tables!");
           System.out.println(e);
       }      
        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        customersTable2 = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;
            }
        };
        jScrollPane4 = new javax.swing.JScrollPane();
        inventoryTable2 = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;
            }
        };
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        order_ID = new javax.swing.JTextField();
        customer_id = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        orderTable = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;
            }
        };
        AddItembtn = new javax.swing.JButton();
        Orderbtn = new javax.swing.JButton();
        RemoveItembtn = new javax.swing.JButton();
        ClearAllbtn = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        GrandTotal = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        Notes5 = new javax.swing.JButton();
        RefreshTable1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        newItem = new javax.swing.JButton();
        editItem = new javax.swing.JButton();
        removeItem = new javax.swing.JButton();
        ExitInv = new javax.swing.JButton();
        RefreshTable = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        inventoryTable = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;
            }
        };
        jButton1 = new javax.swing.JButton();
        Notes1 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        customersTable = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;
            }
        };
        AddCus = new javax.swing.JButton();
        EditCus = new javax.swing.JButton();
        RemoveCus = new javax.swing.JButton();
        ExitCus = new javax.swing.JButton();
        refreshCus = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        TotalOrder = new javax.swing.JTextField();
        OrderTotal = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        Notes4 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        ItemSoldTable = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;
            }
        };
        Calculate = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        AllSales = new javax.swing.JTextField();
        ExitCus1 = new javax.swing.JButton();
        Notes2 = new javax.swing.JButton();
        Total = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        UsersTable = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;
            }
        };
        AddUser = new javax.swing.JButton();
        PromoteUser = new javax.swing.JButton();
        RemoveUser = new javax.swing.JButton();
        DemoteUser = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        Username = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        Pass = new javax.swing.JPasswordField();
        Unlock = new javax.swing.JButton();
        Wrong = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        Notes3 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(56, 142, 60));

        jTabbedPane2.setBackground(new java.awt.Color(56, 142, 60));

        jPanel7.setBackground(new java.awt.Color(102, 187, 106));

        customersTable2.setBackground(new java.awt.Color(128, 64, 16));
        customersTable2.setForeground(new java.awt.Color(255, 255, 255));
        customersTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        customersTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                customersTable2MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(customersTable2);

        inventoryTable2.setBackground(new java.awt.Color(128, 64, 16));
        inventoryTable2.setForeground(new java.awt.Color(255, 255, 255));
        inventoryTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane4.setViewportView(inventoryTable2);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Customer ID:");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Order ID:");

        order_ID.setBackground(new java.awt.Color(128, 64, 16));
        order_ID.setForeground(new java.awt.Color(255, 255, 255));
        order_ID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                order_IDActionPerformed(evt);
            }
        });

        customer_id.setBackground(new java.awt.Color(128, 64, 16));
        customer_id.setForeground(new java.awt.Color(255, 255, 255));
        customer_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customer_idActionPerformed(evt);
            }
        });

        orderTable.setBackground(new java.awt.Color(128, 64, 16));
        orderTable.setForeground(new java.awt.Color(255, 255, 255));
        orderTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Price", "Quantity", "Total"
            }
        ));
        jScrollPane5.setViewportView(orderTable);

        AddItembtn.setBackground(new java.awt.Color(128, 64, 16));
        AddItembtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        AddItembtn.setForeground(new java.awt.Color(255, 255, 255));
        AddItembtn.setText("ADD ITEM");
        AddItembtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddItembtnActionPerformed(evt);
            }
        });

        Orderbtn.setBackground(new java.awt.Color(128, 64, 16));
        Orderbtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Orderbtn.setForeground(new java.awt.Color(255, 255, 255));
        Orderbtn.setText("ENTER ORDER");
        Orderbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OrderbtnActionPerformed(evt);
            }
        });

        RemoveItembtn.setBackground(new java.awt.Color(128, 64, 16));
        RemoveItembtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        RemoveItembtn.setForeground(new java.awt.Color(255, 255, 255));
        RemoveItembtn.setText("REMOVE ITEM");
        RemoveItembtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveItembtnActionPerformed(evt);
            }
        });

        ClearAllbtn.setBackground(new java.awt.Color(128, 64, 16));
        ClearAllbtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ClearAllbtn.setForeground(new java.awt.Color(255, 255, 255));
        ClearAllbtn.setText("CLEAR ALL");
        ClearAllbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearAllbtnActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Grand Total:");

        GrandTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GrandTotalActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(128, 64, 16));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("EXIT");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        Notes5.setBackground(new java.awt.Color(128, 64, 16));
        Notes5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Notes5.setForeground(new java.awt.Color(79, 255, 0));
        Notes5.setText("NOTES");
        Notes5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Notes5ActionPerformed(evt);
            }
        });

        RefreshTable1.setBackground(new java.awt.Color(128, 64, 16));
        RefreshTable1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        RefreshTable1.setForeground(new java.awt.Color(255, 255, 255));
        RefreshTable1.setText("Refresh Tables");
        RefreshTable1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefreshTable1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(123, 123, 123)
                        .addComponent(RefreshTable1)
                        .addGap(83, 83, 83))
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel7Layout.createSequentialGroup()
                            .addGap(125, 125, 125)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(customer_id, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(order_ID, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addComponent(jLabel1)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 483, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 108, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addComponent(RemoveItembtn)
                        .addGap(59, 59, 59)
                        .addComponent(ClearAllbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(AddItembtn)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 446, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 446, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(Orderbtn)
                        .addGap(55, 55, 55)
                        .addComponent(Notes5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(GrandTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(58, 58, 58))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddItembtn)
                    .addComponent(RemoveItembtn)
                    .addComponent(ClearAllbtn))
                .addGap(15, 15, 15)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(customer_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(order_ID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel8)
                        .addComponent(GrandTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(Notes5, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Orderbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(RefreshTable1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(34, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Orders", jPanel7);

        jPanel3.setBackground(new java.awt.Color(102, 187, 106));

        newItem.setBackground(new java.awt.Color(128, 64, 16));
        newItem.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        newItem.setForeground(new java.awt.Color(255, 255, 255));
        newItem.setText("Add A New Item");
        newItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newItemActionPerformed(evt);
            }
        });

        editItem.setBackground(new java.awt.Color(128, 64, 16));
        editItem.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        editItem.setForeground(new java.awt.Color(255, 255, 255));
        editItem.setText("Edit An Existing Item");
        editItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editItemActionPerformed(evt);
            }
        });

        removeItem.setBackground(new java.awt.Color(128, 64, 16));
        removeItem.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        removeItem.setForeground(new java.awt.Color(255, 255, 255));
        removeItem.setText("Remove An Existing Item");
        removeItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeItemActionPerformed(evt);
            }
        });

        ExitInv.setBackground(new java.awt.Color(128, 64, 16));
        ExitInv.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ExitInv.setForeground(new java.awt.Color(255, 255, 255));
        ExitInv.setText("Exit");
        ExitInv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitInvActionPerformed(evt);
            }
        });

        RefreshTable.setBackground(new java.awt.Color(128, 64, 16));
        RefreshTable.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        RefreshTable.setForeground(new java.awt.Color(255, 255, 255));
        RefreshTable.setText("Refresh Table");
        RefreshTable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefreshTableActionPerformed(evt);
            }
        });

        inventoryTable.setBackground(new java.awt.Color(128, 64, 16));
        inventoryTable.setForeground(new java.awt.Color(255, 255, 255));
        inventoryTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane8.setViewportView(inventoryTable);

        jButton1.setText("Search");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        Notes1.setText("Notes");
        Notes1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Notes1ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(128, 64, 16));
        jButton5.setForeground(new java.awt.Color(0, 255, 0));
        jButton5.setText("Notes");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(128, 64, 16));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("SEARCH");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(editItem, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(newItem, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ExitInv, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(removeItem, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(1031, 1031, 1031)
                        .addComponent(Notes1))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(RefreshTable)
                                .addGap(463, 463, 463)
                                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(144, 144, 144)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 723, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton6)
                            .addComponent(RefreshTable))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(newItem, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31)
                        .addComponent(editItem, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31)
                        .addComponent(removeItem, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31)
                        .addComponent(ExitInv, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Notes1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Inventory", jPanel3);

        jPanel5.setBackground(new java.awt.Color(102, 187, 106));

        customersTable.setBackground(new java.awt.Color(128, 64, 16));
        customersTable.setForeground(new java.awt.Color(255, 255, 255));
        customersTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        customersTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                customersTableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(customersTable);

        AddCus.setBackground(new java.awt.Color(128, 64, 16));
        AddCus.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        AddCus.setForeground(new java.awt.Color(255, 255, 255));
        AddCus.setText("ADD CUSTOMER");
        AddCus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddCusActionPerformed(evt);
            }
        });

        EditCus.setBackground(new java.awt.Color(128, 64, 16));
        EditCus.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        EditCus.setForeground(new java.awt.Color(255, 255, 255));
        EditCus.setText("EDIT CUSTOMER");
        EditCus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditCusActionPerformed(evt);
            }
        });

        RemoveCus.setBackground(new java.awt.Color(128, 64, 16));
        RemoveCus.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        RemoveCus.setForeground(new java.awt.Color(255, 255, 255));
        RemoveCus.setText("REMOVE CUSTOMER");
        RemoveCus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveCusActionPerformed(evt);
            }
        });

        ExitCus.setBackground(new java.awt.Color(128, 64, 16));
        ExitCus.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ExitCus.setForeground(new java.awt.Color(255, 255, 255));
        ExitCus.setText("Exit");
        ExitCus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitCusActionPerformed(evt);
            }
        });

        refreshCus.setBackground(new java.awt.Color(128, 64, 16));
        refreshCus.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        refreshCus.setForeground(new java.awt.Color(255, 255, 255));
        refreshCus.setText("REFRESH TABLE");
        refreshCus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshCusActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Total Orders :");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Orders Amount :");

        TotalOrder.setBackground(new java.awt.Color(128, 64, 16));
        TotalOrder.setForeground(new java.awt.Color(255, 255, 255));
        TotalOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TotalOrderActionPerformed(evt);
            }
        });

        OrderTotal.setBackground(new java.awt.Color(128, 64, 16));
        OrderTotal.setForeground(new java.awt.Color(255, 255, 255));

        jButton4.setBackground(new java.awt.Color(128, 64, 16));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("SEARCH");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        Notes4.setBackground(new java.awt.Color(128, 64, 16));
        Notes4.setForeground(new java.awt.Color(79, 255, 0));
        Notes4.setText("Notes");
        Notes4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Notes4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(ExitCus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AddCus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(EditCus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(RemoveCus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(94, 252, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel5))
                                    .addComponent(OrderTotal, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(56, 56, 56))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(refreshCus)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Notes4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(TotalOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(31, 31, 31))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(refreshCus))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(AddCus, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39)
                        .addComponent(EditCus, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39)
                        .addComponent(RemoveCus, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TotalOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(OrderTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Notes4, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(87, 87, 87))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(ExitCus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(105, 105, 105))))
        );

        jTabbedPane2.addTab("Customers", jPanel5);

        jPanel4.setBackground(new java.awt.Color(102, 187, 106));

        ItemSoldTable.setBackground(new java.awt.Color(128, 64, 16));
        ItemSoldTable.setForeground(new java.awt.Color(255, 255, 255));
        ItemSoldTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane6.setViewportView(ItemSoldTable);

        Calculate.setBackground(new java.awt.Color(128, 64, 16));
        Calculate.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Calculate.setForeground(new java.awt.Color(255, 255, 255));
        Calculate.setText("CALCULATE");
        Calculate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CalculateActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Select the rows you wish to Calculate the Total for:");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Total For Selected Rows:");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Total for All Sales:");

        AllSales.setBackground(new java.awt.Color(128, 64, 16));
        AllSales.setForeground(new java.awt.Color(255, 255, 255));

        ExitCus1.setBackground(new java.awt.Color(128, 64, 16));
        ExitCus1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ExitCus1.setForeground(new java.awt.Color(255, 255, 255));
        ExitCus1.setText("EXIT");
        ExitCus1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitCus1ActionPerformed(evt);
            }
        });

        Notes2.setBackground(new java.awt.Color(128, 64, 16));
        Notes2.setForeground(new java.awt.Color(79, 255, 0));
        Notes2.setText("NOTES");
        Notes2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Notes2ActionPerformed(evt);
            }
        });

        Total.setEditable(false);
        Total.setBackground(new java.awt.Color(128, 64, 16));
        Total.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(Notes2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ExitCus1, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(AllSales, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(Calculate, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 245, Short.MAX_VALUE))
                            .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 118, Short.MAX_VALUE)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 679, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(23, 23, 23))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Calculate, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(AllSales, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(ExitCus1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addComponent(Notes2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        jTabbedPane2.addTab("Items Sold", jPanel4);

        jPanel6.setBackground(new java.awt.Color(102, 187, 106));

        UsersTable.setBackground(new java.awt.Color(128, 64, 16));
        UsersTable.setForeground(new java.awt.Color(255, 255, 255));
        UsersTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane7.setViewportView(UsersTable);

        AddUser.setBackground(new java.awt.Color(128, 64, 16));
        AddUser.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        AddUser.setForeground(new java.awt.Color(255, 255, 255));
        AddUser.setText("ADD USER");
        AddUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddUserActionPerformed(evt);
            }
        });

        PromoteUser.setBackground(new java.awt.Color(128, 64, 16));
        PromoteUser.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        PromoteUser.setForeground(new java.awt.Color(255, 255, 255));
        PromoteUser.setText("PROMOTE USER");
        PromoteUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PromoteUserActionPerformed(evt);
            }
        });

        RemoveUser.setBackground(new java.awt.Color(128, 64, 16));
        RemoveUser.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        RemoveUser.setForeground(new java.awt.Color(255, 255, 255));
        RemoveUser.setText("REMOVE USER");
        RemoveUser.setPreferredSize(new java.awt.Dimension(135, 43));
        RemoveUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveUserActionPerformed(evt);
            }
        });

        DemoteUser.setBackground(new java.awt.Color(128, 64, 16));
        DemoteUser.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        DemoteUser.setForeground(new java.awt.Color(255, 255, 255));
        DemoteUser.setText("DEMOTE USER");
        DemoteUser.setPreferredSize(new java.awt.Dimension(135, 43));
        DemoteUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DemoteUserActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Username:");

        Username.setBackground(new java.awt.Color(128, 64, 16));
        Username.setForeground(new java.awt.Color(255, 255, 255));
        Username.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UsernameActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Password:");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("To Unlock The Admin and SuperUser controls please verify your credentials:");

        Pass.setBackground(new java.awt.Color(128, 64, 16));
        Pass.setForeground(new java.awt.Color(255, 255, 255));

        Unlock.setBackground(new java.awt.Color(128, 64, 16));
        Unlock.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Unlock.setForeground(new java.awt.Color(255, 255, 255));
        Unlock.setText("UNLOCK");
        Unlock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UnlockActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(128, 64, 16));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("EXIT");
        jButton2.setPreferredSize(new java.awt.Dimension(135, 43));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        Notes3.setBackground(new java.awt.Color(128, 64, 16));
        Notes3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Notes3.setForeground(new java.awt.Color(79, 255, 0));
        Notes3.setText("NOTES");
        Notes3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Notes3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(RemoveUser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DemoteUser, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AddUser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(PromoteUser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 228, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel6Layout.createSequentialGroup()
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(Wrong, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel6Layout.createSequentialGroup()
                                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(Username, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(81, 81, 81)
                                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(Pass, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(18, 18, 18)
                                    .addComponent(Unlock)))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Notes3, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 696, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(AddUser, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(PromoteUser, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36)
                        .addComponent(DemoteUser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(RemoveUser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel9)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel6))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Username)
                                    .addComponent(Pass)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(Unlock, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Notes3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Wrong, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane2.addTab("ManageUsers ", jPanel6);

        jPanel1.setBackground(new java.awt.Color(56, 142, 60));

        jLabel14.setIcon(new javax.swing.ImageIcon("/home/kylie/Downloads/Vine png.png")); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1128, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 456, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    //ADD ITEM BUTTON
    private void newItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newItemActionPerformed
        AddAnItem obj = new AddAnItem();
        obj.setVisible(true);
    }//GEN-LAST:event_newItemActionPerformed

    
    //EDIT AN ITEM BUTTON
    private void editItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editItemActionPerformed
        EditAnItem obj = new EditAnItem();
        obj.setVisible(true);
    }//GEN-LAST:event_editItemActionPerformed

    
    //REMOVE ITEM BUTTON
    private void removeItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeItemActionPerformed
        RemoveAnItem obj = new RemoveAnItem();
        obj.setVisible(true);
    }//GEN-LAST:event_removeItemActionPerformed

    private void ExitInvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitInvActionPerformed
        System.exit(0);
    }//GEN-LAST:event_ExitInvActionPerformed

    
    //REFRESH TABLE
    private void RefreshTableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshTableActionPerformed
        Update_table();
        JOptionPane.showMessageDialog(null, "Refresh Complete");
    }//GEN-LAST:event_RefreshTableActionPerformed

    
    //ADD CUSTOMER
    private void AddCusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddCusActionPerformed
        AddCustomer obj = new AddCustomer();
        obj.setVisible(true);
    }//GEN-LAST:event_AddCusActionPerformed

    private void ExitCusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitCusActionPerformed
        System.exit(0);
    }//GEN-LAST:event_ExitCusActionPerformed

    
    //REFRESH CUSTOMER
    private void refreshCusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshCusActionPerformed
        Update_table();
        JOptionPane.showMessageDialog(null, "Refresh Complete");
    }//GEN-LAST:event_refreshCusActionPerformed

    private void AddItembtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddItembtnActionPerformed
        DefaultTableModel modelinventory = (DefaultTableModel) inventoryTable2.getModel();
        int [ ] indexes = inventoryTable2.getSelectedRows();
        Object [ ] row = new Object [5];
        DefaultTableModel modelorder = (DefaultTableModel) orderTable.getModel();
        
        
        String howmany = JOptionPane.showInputDialog(null, "How many would you like?");
        if(howmany != null){
             //Asks how many items user wishes to buy
        int Howmany = Integer.parseInt(howmany);
        int Rows = inventoryTable2.getSelectedRow();
        
        //To compare if Howmany is more than inventory available
        int IsQuantityOver = (int) inventoryTable2.getValueAt(Rows,3);
        
        if((IsQuantityOver >= Howmany) && Howmany != 0){
        double price = Double.parseDouble(modelinventory.getValueAt(Rows,2).toString());
        double total = price * Howmany;
        
        
        for (int i = 0; i < indexes.length; i++){   
            row [0] = modelinventory.getValueAt(indexes [i], 0);
            row [1] = modelinventory.getValueAt(indexes [i], 1);
            row [2] = modelinventory.getValueAt(indexes [i], 2);
            row [3] = howmany;
            row [4] = total;
            modelorder.addRow(row);     
           
        }
        
        //To calculate the grandtotal
        double grandtotal = 0.0;
        int  Rowscount = orderTable.getRowCount();
        double amt;
        for (int z = 0; z < Rowscount; z++){
            amt = Double.parseDouble(orderTable.getValueAt(z, 4).toString());
            grandtotal += amt;
           }
        GrandTotal.setText(Double.toString(grandtotal));      
        }else{
            JOptionPane.showMessageDialog(null, "Cannot Order more than is available or zero, Try again","Notice",JOptionPane.ERROR_MESSAGE);
        }
        }
        
       
    }//GEN-LAST:event_AddItembtnActionPerformed

    private void EditCusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditCusActionPerformed
        editCustomer obj = new editCustomer();
        obj.setVisible(true);
    }//GEN-LAST:event_EditCusActionPerformed

    private void RemoveCusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveCusActionPerformed
        deleteCustomer obj = new deleteCustomer();
        obj.setVisible(true);
    }//GEN-LAST:event_RemoveCusActionPerformed

    private void RemoveItembtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveItembtnActionPerformed
        DefaultTableModel modelorder = (DefaultTableModel) orderTable.getModel();
        int Row = orderTable.getSelectedRow();
        modelorder.removeRow(Row);
        
    }//GEN-LAST:event_RemoveItembtnActionPerformed

    private void GrandTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GrandTotalActionPerformed
        
    }//GEN-LAST:event_GrandTotalActionPerformed

    private void customersTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_customersTable2MouseClicked
        DefaultTableModel modelCustomer = (DefaultTableModel) customersTable2.getModel();
        int row = customersTable2.getSelectedRow();
        customer_id.setText(modelCustomer.getValueAt(row, 0).toString());
    }//GEN-LAST:event_customersTable2MouseClicked

    private void customer_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customer_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_customer_idActionPerformed

    private void order_IDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_order_IDActionPerformed
        
    }//GEN-LAST:event_order_IDActionPerformed

    private void OrderbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrderbtnActionPerformed
        DefaultTableModel modelcustomer = (DefaultTableModel) customersTable2.getModel();
        int CusRow = customersTable2.getSelectedRow();
        int GR = orderTable.getRowCount();
            
        try {
            
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dates = new Date();
        String strDateFormat = "hh:mm:ss";
        String s = sdf.format(dates);
        DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
        String formattedDate = dateFormat.format(dates);
        java.util.Date date = new java.util.Date();
           
          
           
           
           
            //insert into orderdetails Table
           
           java.sql.Date sqlDate=new java.sql.Date(date.getTime());          
            int Customer_id = (int) customersTable2.getValueAt(CusRow,0);
            double Grand_Total = Double.parseDouble(GrandTotal.getText());
            
            PreparedStatement stmt;
            stmt = con.prepareStatement("INSERT INTO ordertbl VALUES(NULL,?,?,?,?)");
            stmt.setInt(1, Customer_id);
            stmt.setString(2,s);
            stmt.setString(3,formattedDate);
            stmt.setDouble(4, Grand_Total);
            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null,"Successfully Ordered!","Notice",JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"You have left a field blank","Error",JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        }
        
        //Remove item count from stock and add details to orderdetails
        try{
            int valuesused[];
            valuesused = new int [9];
            
            DefaultTableModel model = (DefaultTableModel) orderTable.getModel();
            int z = 0;
           
            do{
                double Grand_Total = (Double)(orderTable.getValueAt(z,4));
                String Name = (String) (orderTable.getValueAt(z,1));
                System.out.println(Name);
                String Quant = (String) orderTable.getValueAt(z, 3);
                int Quantity = Integer.parseInt(Quant);
                System.out.println(Quantity);
                int ID = (int)orderTable.getValueAt(z,0);
                double Price = (double)orderTable.getValueAt(z,2);
                int Orderid = Integer.parseInt(order_ID.getText());
                System.out.println(Orderid);
                PreparedStatement stmt;
                stmt = con.prepareStatement("UPDATE `inventory` SET `Quantity`= Quantity - "+Quantity+" WHERE id  = "+ID+"");
                stmt.executeUpdate();
                
                
                valuesused[z] = ID;
                
                boolean check = false;
                for(int i = 0; i <=z; i++){
                
                    if(z==0){
                    break;
                    }
                    
                    if(i==z){
                        break;
                    }
                    if (valuesused[i] == ID){
                    stmt = con.prepareStatement("UPDATE `orderdetails` SET `Quantitysold`= Quantitysold + "+Quantity+" WHERE orderid  = "+order_id+"AND 'Itemname='"+Name+"'");
                     stmt.executeUpdate();
                     valuesused[z]=z;
                     System.out.println("the check is tru");
                     check=true;
                     break;
                }
                    System.out.println("the check is false");
                    System.out.println(valuesused[z]);
                }
               if(check==true){
                   System.out.println("this check was reached");
                   z++;
                     
               }else if(check == false){
              
                System.out.println("the insert occured");
                stmt = con.prepareStatement("INSERT INTO orderdetails (Orderid,Itemname,Price,Quantitysold,Total) VALUES (?,?,?,?,?)");
                stmt.setInt(1,Orderid);
                stmt.setString(2,Name);
                stmt.setDouble(3,Price);
                stmt.setInt(4,Quantity);
                stmt.setDouble(5,Grand_Total);
                stmt.execute();
                stmt.close();
                   System.out.println("statement finished");
                z++;
               }
            }while(z <= GR);
             
          
           
            
        }
        catch(Exception e){
        System.out.println(e);
        }
        
        
        
         order_id++;
         order_ID.setText(Integer.toString(order_id));
        Update_table();
    }//GEN-LAST:event_OrderbtnActionPerformed

    private void ClearAllbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearAllbtnActionPerformed
        DefaultTableModel modelorder = (DefaultTableModel) orderTable.getModel();
        modelorder.setRowCount(0);
        GrandTotal.setText("");
    }//GEN-LAST:event_ClearAllbtnActionPerformed

    private void customersTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_customersTableMouseClicked
        int rows = customersTable.getSelectedRow();
        int custID = (int) customersTable.getValueAt(rows,0);
    try {
           String sql = "SELECT COUNT(Orderid) FROM ordertbl WHERE Customerid = "+custID+"";
           stmt = con.prepareStatement(sql);
           rs = stmt.executeQuery();
           while(rs.next()){
               int TotalOrders = rs.getInt(1);
               TotalOrder.setText(Integer.toString(TotalOrders));
           }
           
           sql = "SELECT SUM(Grandtotal) FROM ordertbl WHERE Customerid = "+custID+"";
           stmt = con.prepareStatement(sql);
           rs = stmt.executeQuery();
           while(rs.next()){
               double OrdersTotal = rs.getInt(1);
               OrderTotal.setText(Double.toString(OrdersTotal));
           }
        
    } catch (Exception e) {
       System.out.println(e);
    }
        
        
        
    }//GEN-LAST:event_customersTableMouseClicked

    private void TotalOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TotalOrderActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TotalOrderActionPerformed

    
    //Add User Button
    private void AddUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddUserActionPerformed
            
           
         try{
            UserName = JOptionPane.showInputDialog(null,"Enter the Username");
            if (UserName != null){    
                  Password = JOptionPane.showInputDialog(null,"Enter Password",JOptionPane.OK_CANCEL_OPTION);
            if(Password != null){
                        int sure = JOptionPane.showConfirmDialog(null, "Are you sure you wish to add the user?");
                        if (sure == 0){
                            PreparedStatement stmt;
                            stmt = con.prepareStatement("INSERT INTO users (`Username`,`Password`) VALUES(?,?)");
                            stmt.setString(1, UserName);
                            stmt.setString(2, Password);
                            stmt.execute();
                            System.out.println("Completed");
                            stmt.close();
                            JOptionPane.showMessageDialog(null,"User Added Successfully","Notice",JOptionPane.INFORMATION_MESSAGE);
                            Update_table();
                        }
            }
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"You have entered an invalid value","Error",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_AddUserActionPerformed

    
    //Promote user button
    private void PromoteUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PromoteUserActionPerformed
        try{
            DefaultTableModel model = (DefaultTableModel)UsersTable.getModel();
            int Row = UsersTable.getSelectedRow();
            String Role = "Admin";
            String ID = (model.getValueAt(Row, 0).toString());
            String user = (String) (model.getValueAt(Row,1));
            System.out.println(user);
            if (user.equals("Admin"))
             {
                JOptionPane.showMessageDialog(null,"Selected is already an Admin");
            }else if (user.equals("User")){ 
            PreparedStatement stmt;
            stmt = con.prepareStatement("UPDATE users SET Role= ? WHERE Userid = ? ");
            stmt.setString(1, Role);
            stmt.setString(2, ID);
            stmt.execute();
            System.out.println("Completed");
            stmt.close();
            JOptionPane.showMessageDialog(null,"User Promoted Successfully");
            Update_table();
            }else if (user.equals("SuperUser")){
            JOptionPane.showMessageDialog(null,"The Super user cannot be promoted or demoted");
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }//GEN-LAST:event_PromoteUserActionPerformed

    
    //Demote User button
    private void DemoteUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DemoteUserActionPerformed

        try{
            DefaultTableModel model = (DefaultTableModel)UsersTable.getModel();
            int Row = UsersTable.getSelectedRow();
            String Role = "User";
            String ID = (model.getValueAt(Row, 0).toString());
            String user = (String) (model.getValueAt(Row,1));
            System.out.println(user);
            if (user.equals("User"))
             {
                JOptionPane.showMessageDialog(null,"Selected is already a User");
            }else if (user.equals("Admin")){ 
            
            PreparedStatement stmt;
            stmt = con.prepareStatement("UPDATE users SET Role= ? WHERE Userid = ? ");
            stmt.setString(1, Role);
            stmt.setString(2, ID);
            stmt.execute();
            System.out.println("Completed");
            stmt.close();
            JOptionPane.showMessageDialog(null,"User Demoted Successfully");
            Update_table();
            }else if (user.equals("SuperUser")){
            JOptionPane.showMessageDialog(null,"The Super user cannot be promoted or demoted");
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }//GEN-LAST:event_DemoteUserActionPerformed

    
    //Remove User button
    private void RemoveUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveUserActionPerformed
         try{
            DefaultTableModel model = (DefaultTableModel)UsersTable.getModel();
            int Row = UsersTable.getSelectedRow();
            String ID = (model.getValueAt(Row, 0).toString());
            String user = (String) (model.getValueAt(Row,1));
            if (user.equals("SuperUser"))
             {
                JOptionPane.showMessageDialog(null,"The SuperUser cannot be removed","Error",JOptionPane.INFORMATION_MESSAGE);
            }else if(user.equals("Admin") || user.equals("User")){
            PreparedStatement stmt;
            stmt = con.prepareStatement("DELETE FROM users WHERE Userid = ?");
            stmt.setString(1, ID);
            stmt.execute();
            JOptionPane.showMessageDialog(null,"User deleted successfully!");
            stmt.close();
            Update_table();
            }
        }catch(Exception e){
            System.out.println(e);
        }
         
    }//GEN-LAST:event_RemoveUserActionPerformed

    private void UnlockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UnlockActionPerformed
       username = Username.getText();
       password = Pass.getText();
       
       try{
         PreparedStatement stmt;
         stmt = con.prepareStatement("SELECT * FROM users WHERE Username = BINARY ? AND Password = BINARY ? ");
         stmt.setString(1,Username.getText());
         stmt.setString(2,Pass.getText());
         rs = stmt.executeQuery();
         if (rs.next()){
             if ((rs.getString("Username").equals(username)) && rs.getString("Password").equals(password) && rs.getString("role").equals("Admin")){
                 AddUser.setEnabled(true);
                 RemoveUser.setEnabled(true);
                   String sql = "SELECT Userid, Role, Username FROM users";
                   stmt = con.prepareStatement(sql);
                   rs = stmt.executeQuery();
                   UsersTable.setModel(DbUtils.resultSetToTableModel(rs));
                   Pass.setText("");
                   JOptionPane.showMessageDialog(null, "Unlocked");
             }
         else if ((rs.getString("Username").equals(username)) && rs.getString("Password").equals(password) && rs.getString("role").equals("SuperUser")){
                   AddUser.setEnabled(true);
                   RemoveUser.setEnabled(true);
                   PromoteUser.setEnabled(true);
                   DemoteUser.setEnabled(true);
                   String sql = "SELECT Userid,Role,Username FROM users";
                   stmt = con.prepareStatement(sql);
                   rs = stmt.executeQuery();
                   UsersTable.setModel(DbUtils.resultSetToTableModel(rs));
                   Pass.setText("");
                   JOptionPane.showMessageDialog(null, "Unlocked");
         }
         else if (!rs.getString("Username").equals(username) || !rs.getString("Password").equals(password)){
                  Wrong.setText("Incorrect Credentials");
                  JOptionPane.showMessageDialog(null,"Incorrect Credentials");         
         }
         }   
      }catch(Exception e){
          System.out.println(e);
          
      }
    }//GEN-LAST:event_UnlockActionPerformed

    //search button for inventory table
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try{
            JFrame frame = new JFrame("Search Dialog");
            String code = "%" + JOptionPane.showInputDialog(frame,"Search Here:","Itemname Search",JOptionPane.QUESTION_MESSAGE) + "%";
             if (code.equals("%null%")){
            
           }else{
            PreparedStatement stmt;
            stmt = con.prepareStatement("SELECT * FROM inventory WHERE Itemname LIKE ?");
            stmt.setString(1,code);
            rs = stmt.executeQuery();
            inventoryTable.setModel(DbUtils.resultSetToTableModel(rs));
             }
        }catch(Exception e){
        System.out.println(e);
                }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void CalculateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CalculateActionPerformed
        jLabel11.setVisible(true);
        Total.setVisible(true);
        int [ ] indexes = ItemSoldTable.getSelectedRows();
        double total = 0.0;
        for (int i = 0; i < indexes.length; i++){   
            double ttotal = (double) ItemSoldTable.getValueAt(indexes[i],2);  
            int quantity = (Integer)ItemSoldTable.getValueAt(indexes[i],3);
            double result = ttotal * quantity;
            total += result;
        }
        Total.setText(Double.toString(total));
    }//GEN-LAST:event_CalculateActionPerformed

    private void ExitCus1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitCus1ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_ExitCus1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      System.exit(0);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
         try{
            JFrame frame = new JFrame("Search Dialog");
            String code =  "%" + JOptionPane.showInputDialog(frame,"Search Here:","What would you like to search?",JOptionPane.QUESTION_MESSAGE) + "%";
           if (code.equals("%null%")){
            
           }else{
            PreparedStatement stmt;
            stmt = con.prepareStatement("SELECT * FROM customers WHERE Firstname LIKE ? OR Lastname LIKE ? OR Address LIKE ? OR Telephone LIKE ? OR Email LIKE ?");
            stmt.setString(1,code);
            stmt.setString(2,code);
            stmt.setString(3,code);
            stmt.setString(4,code);
            stmt.setString(5,code);
            rs = stmt.executeQuery();
            customersTable.setModel(DbUtils.resultSetToTableModel(rs));
           }
        }catch(Exception e){
        System.out.println(e);
                }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void Notes1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Notes1ActionPerformed
        MyNotepad obj = new MyNotepad();
        obj.setVisible(true);
    }//GEN-LAST:event_Notes1ActionPerformed

    private void Notes2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Notes2ActionPerformed
        MyNotepad obj = new MyNotepad();
        obj.setVisible(true);
    }//GEN-LAST:event_Notes2ActionPerformed

    private void Notes3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Notes3ActionPerformed
        MyNotepad obj = new MyNotepad();
        obj.setVisible(true);
    }//GEN-LAST:event_Notes3ActionPerformed

    private void Notes4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Notes4ActionPerformed
        MyNotepad obj = new MyNotepad();
        obj.setVisible(true);
    }//GEN-LAST:event_Notes4ActionPerformed

    private void Notes5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Notes5ActionPerformed
        MyNotepad obj = new MyNotepad();
        obj.setVisible(true);
    }//GEN-LAST:event_Notes5ActionPerformed

    private void UsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UsernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UsernameActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       MyNotepad obj = new MyNotepad();
        obj.setVisible(true);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void RefreshTable1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshTable1ActionPerformed
        Update_table();
        JOptionPane.showMessageDialog(null, "Refresh Complete");
    }//GEN-LAST:event_RefreshTable1ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
       try{
            JFrame frame = new JFrame("Search Dialog");
            String code = "%" + JOptionPane.showInputDialog(frame,"Search Here:","Itemname Search",JOptionPane.QUESTION_MESSAGE) + "%";
             if (code.equals("%null%")){
            
           }else{
            PreparedStatement stmt;
            stmt = con.prepareStatement("SELECT * FROM inventory WHERE Itemname LIKE ?");
            stmt.setString(1,code);
            rs = stmt.executeQuery();
            inventoryTable.setModel(DbUtils.resultSetToTableModel(rs));
             }
        }catch(Exception e){
        System.out.println(e);
                }
    }//GEN-LAST:event_jButton6ActionPerformed
    
   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InventorysystemUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InventorysystemUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InventorysystemUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InventorysystemUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                 InventorysystemUI Inventory=new InventorysystemUI();
           Inventory.setVisible(true);
               
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddCus;
    private javax.swing.JButton AddItembtn;
    private javax.swing.JButton AddUser;
    private javax.swing.JTextField AllSales;
    private javax.swing.JButton Calculate;
    private javax.swing.JButton ClearAllbtn;
    private javax.swing.JButton DemoteUser;
    private javax.swing.JButton EditCus;
    private javax.swing.JButton ExitCus;
    private javax.swing.JButton ExitCus1;
    private javax.swing.JButton ExitInv;
    private javax.swing.JTextField GrandTotal;
    private javax.swing.JTable ItemSoldTable;
    private javax.swing.JButton Notes1;
    private javax.swing.JButton Notes2;
    private javax.swing.JButton Notes3;
    private javax.swing.JButton Notes4;
    private javax.swing.JButton Notes5;
    private javax.swing.JTextField OrderTotal;
    private javax.swing.JButton Orderbtn;
    private javax.swing.JPasswordField Pass;
    private javax.swing.JButton PromoteUser;
    private javax.swing.JButton RefreshTable;
    private javax.swing.JButton RefreshTable1;
    private javax.swing.JButton RemoveCus;
    private javax.swing.JButton RemoveItembtn;
    private javax.swing.JButton RemoveUser;
    private javax.swing.JTextField Total;
    private javax.swing.JTextField TotalOrder;
    private javax.swing.JButton Unlock;
    private javax.swing.JTextField Username;
    private javax.swing.JTable UsersTable;
    private javax.swing.JLabel Wrong;
    private javax.swing.JTextField customer_id;
    private javax.swing.JTable customersTable;
    private javax.swing.JTable customersTable2;
    private javax.swing.JButton editItem;
    private javax.swing.JTable inventoryTable;
    private javax.swing.JTable inventoryTable2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JButton newItem;
    private javax.swing.JTable orderTable;
    private javax.swing.JTextField order_ID;
    private javax.swing.JButton refreshCus;
    private javax.swing.JButton removeItem;
    // End of variables declaration//GEN-END:variables
}
