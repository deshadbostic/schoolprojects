//Start of Profile Display Page
for (i = 0; i < localStorage.length; i++){
  var key = localStorage.key(i);
  var value = localStorage.getItem(key);
  var Name =  `${value}<br/>`;

}

function Welcome(){
  if (Name == null){
    document.write("Please Sign Up using the Add Profile link Above");
}else {
  document.write("Welcome to NAME OF APPLICATION " + Name);
}
}







//End of Profile Display Page



//Start of Add Profile Page
function calculate(){
    var Username = document.getElementById("UName").value;
    var Password = document.getElementById("Pword").value;

    // Check browser support
    if (typeof(Storage) !== "undefined") {
            // Store
            localStorage.setItem("Username",Username)
            localStorage.setItem("Password", Password);
            // Retrieve
            for (i = 0; i < localStorage.length; i++){
              const key = localStorage.key(i);
              const value = localStorage.getItem(key);
            }

            alert("The user has been successfully created");

    }else{
            document.getElementById("result").innerHTML = "Sorry, your browser does not support Web Storage...";
         }

}

//End of Add Profile Page


//Start of Input Gift List items
/*
function addWishRow(){
  var recipient_Name = document.getElementsById("recipientName").value;
  var gift_name = document.getElementById("Gift").value;
  var price_cost = document.getElementsByClassId("Price").value;
  var occasion_for = document.getElementsByClassId("occasion").value;
  var location_from = document.getElementsByClassId("location").value;
  var purchased_yet = document.getElementsByClassId("purchased").value;

  var wishList = {
    recipient = recipient_Name,
    gift = gift_name,
    price = price_cost,
    occasion = occasion_for,
    location = location_from,
    purchased = purchased_yet
  };


  db.put(contact, function callback(err, result){
    if(!err){
      console.log('Succesfully saved a row!');
      alert("Details Saved!");
    }
  });
}

*/
//End of Input Gift List Items
