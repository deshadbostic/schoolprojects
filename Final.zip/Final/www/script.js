<script>
document.write("Hi there");
</script>
